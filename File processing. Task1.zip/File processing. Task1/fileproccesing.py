import csv
import random

filename = "students.csv"
filename1 = "subjects.txt"
filename2 = "TopStudent.txt"


students1 = [["Mariami1", random.randint(1, 100), random.randint(1, 100), random.randint(1, 100)],
             ["Anano1", random.randint(1, 100), random.randint(1, 100), random.randint(1, 100)],
             ["Tornike1", random.randint(1, 100), random.randint(1, 100), random.randint(1, 100)],
             ["Gigi1", random.randint(1, 100), random.randint(1, 100), random.randint(1, 100)],
             ["Iosebi1", random.randint(1, 100), random.randint(1, 100), random.randint(1, 100)]]

subjects = ["Math", "History", "Science"]

try:

    with open(filename, 'w', newline='') as file:
      writer = csv.writer(file)
      writer.writerows(students1)
except Exception  as e :
    print("We can't find the file named {filename}")
try:
    with open(filename1, "w", newline='') as file:
        for subject in subjects:
            file.write(subject + "\n")
except Exception  as e :
    print("We can't find the file named {filename1}")

studentsdata = []
try:
    with open(filename, "r") as file:
        reader = csv.reader(file)
        studentsdata = [row for row in reader]
except Exception  as e :
    print("Can't read the file ")
try:
    with open(filename1, "r") as file:
        subjects = file.read().splitlines()
except Exception  as e :
    print("Can't read the file ")

student_grades = {}

for student in studentsdata:
    name = student[0]
    grades = student[1:]
    if len(grades) == len(subjects):
       studentsubjectgrades = {}
       for i in range(len(subjects)):
            subject = subjects[i]
            grade = int(grades[i])
            studentsubjectgrades[subject] = grade
    student_grades[name] = studentsubjectgrades

print(student_grades)


averages = {}
for student, grades in student_grades.items():
    summ = sum(grades.values())
    total = len(grades)
    average = summ / total
    averages[student] = average

print(averages)


highestgradestudent = None
highestaverage = 0
for student, average in averages.items():
    if  average > highestaverage:
        highestaverage = average
        highestgradestudent = student

print(f"highest average grade has {highestgradestudent}: {highestaverage}")

topstudent = student_grades[highestgradestudent]

with open(filename2, "w") as file:
    file.write(f"Name : {highestgradestudent} \n")
    file.write("Grades: \n")
    for subject, grade in topstudent.items():
        file.write(f"{subject} : {grade} \n")   
    file.write(f"Average grade: {highestaverage} \n ")