import numpy  as np
from PIL import Image

print("Task 1")
img = Image.open(r"disnayland.jpg")
img.show()
numpy_array = np.array(img)
print(numpy_array.shape)

print("Task 2")
rotate_array = np.rot90(numpy_array)
rotate_image = Image.fromarray(rotate_array)
rotate_image.show()

rotate_array_180 = np.rot90(rotate_array)
rotate_image_180 = Image.fromarray(rotate_array_180)
rotate_image_180.show()

rotate_array_270 = np.rot90(rotate_array_180)
rotate_image_270 = Image.fromarray(rotate_array_270)
rotate_image_270.show()

print("Task 3")
increase = 1.5 
decrease = 0.5 
increase_array = np.clip(numpy_array * increase , 0, 255).astype(np.uint8)
increase_image = Image.fromarray(increase_array)
increase_image.show()

decrease_array = np.clip(numpy_array * decrease, 0 ,255).astype(np.uint8)
decrease_image = Image.fromarray(decrease_array)
decrease_image.show()


print("Task 4")
height , width = numpy_array.shape[:2]

crop_height = height // 2
crop_width = width // 2
start_from_x = (width - crop_width) // 2 
star_from_y = (height - crop_height ) // 2 
end_x = width - start_from_x
end_y = height - star_from_y 
crop_array = numpy_array[star_from_y:end_y, start_from_x:end_x]
crop_image = Image.fromarray(crop_array)
crop_image.show()

print("Task 5")
mean = np.mean(numpy_array)
print("Mean value is: " , mean)

max = np.max(numpy_array)
print("Max value is: ", max)

min = np.min(numpy_array)
print("Min value is: ", min)

sum = np.sum(numpy_array)
print("Summ is:" , sum)

print("Task 6")
save_path = r'C:\Users\User\Desktop\numpy Image manipulation\\'
crop_image.save(save_path + 'cropped_image.png')
decrease_image.save(save_path + 'decreased_image.png')
increase_image.save(save_path + 'increased_image.png')
rotate_image.save(save_path + 'rotated_image_90.png')
rotate_image_180.save(save_path + 'rotated_image_180.png')
rotate_image_270.save(save_path + 'rotated_image_270.png')
